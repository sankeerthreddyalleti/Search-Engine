package searchengine;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;



public class SearchEngine 
{
	static ArrayList<String> aList = new ArrayList<String>();
	static Hashtable<String, Integer> hashTable = new Hashtable<String, Integer>();

	public int searchWord(File filePath, String p1) throws IOException, NullPointerException //Gives you the occurence and the position of the word
	{
		int count = 0;
		String datalog = "";
		BufferedReader bufferReader = new BufferedReader(new FileReader(filePath));
		String line = null;
		while ((line = bufferReader.readLine()) != null)
		{
			datalog = datalog + line;
		}
		bufferReader.close();
		String txt = datalog;
		BoyerMoore bm = new BoyerMoore(p1);
		int offset = 0;
		for (int loc = 0; loc <= txt.length(); loc += offset + p1.length())
		{
			  offset = bm.search(p1, txt.substring(loc));
			  if ((offset + loc) < txt.length())
			  { 
				  count++; 
				  System.out.printf("The word '"+p1 +"' being searched is present at position : " + (offset + loc)+"\n"); 
				  //here the position of word being searched is printed
			  } 
		}
		if(count!=0)
		{ 
			  System.out.println("It is in the file: "+filePath.getName()+"\n");
		}
		return count; 
	}                                                          // End of function searchWord()

	// Ranking of Web Pages using merge sort
	// Collections.sort by default uses merge sort
	public void rank(Hashtable<?, Integer> fname, int occurance)
	{
		// Transfer as List and sort it
		ArrayList<Map.Entry<?, Integer>> list = new ArrayList<Entry<?, Integer>>(fname.entrySet());
		Collections.sort(list, new Comparator<Map.Entry<?, Integer>>()
		{
			public int compare(Map.Entry<?, Integer> obj1, Map.Entry<?, Integer> obj2)
			{
				return obj1.getValue().compareTo(obj2.getValue());
			}
		});
		Collections.reverse(list);
		
		if (occurance != 0)
		{
			System.out.println("\nThe Top Five Search Results Are Shown\n");
			int res = 5;
			int j = 1;
			while (list.size() > j && res > 0)
			{
				System.out.println("(" + j + ") " + list.get(j) + " times ");
				j++;
				res--;
			}
		}
	}                                                        //End of function rankFiles()

	/* using regex to find similar string to pattern */
	@SuppressWarnings("rawtypes")
	public void suggestword(String pattern) throws Exception
	{
			// String to be scanned to find the pattern.
			String line = " ";
			String fileReg = "[\\w]+[@$%^&*()!?{}\b\n\t]*";

			// Create a Pattern object
			Pattern p = Pattern.compile(fileReg);
			
			// Now create matcher object.
			Matcher m = p.matcher(line);
			
			int fileNum = 0;
			
				File directory = new File("C:\\Users\\asus\\Desktop\\SearchEngine\\src\\Webpages\\Text");
				File[] fileArray = directory.listFiles();
				for (int i = 0; i < fileArray.length; i++)
				{
					find(fileArray[i], fileNum, m, pattern);                  
					fileNum++;
				}

				
				@SuppressWarnings({ "unused" })
				Set keys = new HashSet();
				Integer value1 = 1;
				Integer value2 = 0;
				int counter = 0;

				System.out.println("\nDo you mean?:");
				for (Map.Entry entry : hashTable.entrySet())
				{
					if (value2 == entry.getValue())
					{
						break;
					}
					else
					{
						if (value1 == entry.getValue())
						{
							if (counter == 0)
							{
								System.out.print(entry.getKey());
								counter++;
							}
							else
							{
								System.out.print(" , " + entry.getKey());
								counter++;
							}

						} 

					}   
				}       
	}                                                

	
	// The find function finds strings with similar patterns and calls edit distance() on those strings
	public void find(File sourceFile, int fileNumber, Matcher match, String str) 
			throws FileNotFoundException, ArrayIndexOutOfBoundsException, IOException
	{
		
			BufferedReader br = new BufferedReader(new FileReader(sourceFile));
			String line = null;
			while ((line = br.readLine())!= null)
			{
				match.reset(line);
				while (match.find())
				{
					aList.add(match.group());
				}
			}
			br.close();
			for (int p = 0; p < aList.size(); p++)
			{
				hashTable.put(aList.get(p), editDistance(str.toLowerCase(), aList.get(p).toLowerCase()));
			}

	}                                    // End of function findWord()

	
	// Using Edit distance to compare nearest distance between the keyword and similar words
	// patterns obtained from regex
	public static int editDistance(String str1, String str2)
	{
		int length1 = str1.length();
		int length2 = str2.length();

		int[][] arr = new int[length1 + 1][length2 + 1];

		for (int i = 0; i <= length1; i++)
		{
			arr[i][0] = i;
		}
		for (int j = 0; j <= length2; j++)
		{
			arr[0][j] = j;
		}

		// iterate though, and check last char
		for (int i = 0; i < length1; i++)
		{
			char c1 = str1.charAt(i);
			for (int j = 0; j < length2; j++)
			{
				char c2 = str2.charAt(j);

				if (c1 == c2)
				{
					arr[i + 1][j + 1] = arr[i][j];
				}
				else
				{
					int replace = arr[i][j] + 1;
					int insert = arr[i][j + 1] + 1;
					int delete = arr[i + 1][j] + 1;

					int min = replace > insert ? insert : replace;
					min = delete > min ? min : delete;
					arr[i + 1][j + 1] = min;
				}
			}
		}

		return arr[length1][length2];
	}                                                  // End of function editDistance()

	public void search(String word)
	{
		Hashtable<String, Integer> hashtable = new Hashtable<String, Integer>();
		File dir = new File("C:\\Users\\asus\\Desktop\\SearchEngine\\src\\Webpages\\Text");
		File[] fileArray = dir.listFiles();
		int repeats = 0;    // No. of times the searched word repeated in a same file
		int numofFiles = 0; // No. of files that contains the Searched word
		try
		{
			long startTime = System.nanoTime();
			long startTimesearch = System.nanoTime();
			for (int i = 1; i < fileArray.length; i++)
			{
				repeats = searchWord(fileArray[i], word);
				hashtable.put(fileArray[i].getName(), repeats);
				if (repeats != 0)
				{
					numofFiles++;
					if (fileArray[i].getName().toString().substring(0, 3) == "null")
					{
						fileArray[i].getName().toString();
					}
				}
			}
			System.out.println("\nThe total no.of files containing the word " + word + " are = " + numofFiles);
			long endTimesearch = System.nanoTime();
			long srchtime = endTimesearch - startTimesearch;
			System.out.println("\nTotal time taken for searching: " + srchtime/1000000 + " Milli Seconds");
			if (numofFiles == 0)
			{
				System.out.println("\nSearching words which are related");
				suggestword(word);
			}

				long rankstart = System.nanoTime();
					rank(hashtable, numofFiles);
				long rankend = System.nanoTime();
				long rankingTime = rankend - rankstart;
			System.out.println("\nTime taken for Ranking: " + rankingTime + " nano Seconds");
			
			long endTime = System.nanoTime();
			System.out.println("\nTime taken for total execution: " + (endTime - startTime)/1000000 + " milli Seconds");
		}
		catch (Exception e)
		{
			System.out.println("Exception:" + e);
		}
	}                                                 // End of function search()

	public static void main(String args[])
	{
		int g;
		String word;
		Scanner input = new Scanner(System.in);
		SearchEngine websearch = new SearchEngine();
		while(true)
		{
			System.out.printf("--------Welcome to Our Search Engine--------\n");
			System.out.printf("Please choose your option from below:\n");
			System.out.printf("1. Start your search \n2. Exit\nOption : ");
			g = input.nextInt();
			input.nextLine();
			switch(g)
			{
				case 1:
				{
					System.out.printf("Enter the Word to Search : ");
					word = input.nextLine();
					websearch.search(word);
					break;
				}
				case 2:
				{
					input.close();
					System.exit(0);
				}
			}         // End of Switch case
		}             // End of while loop
	}                                                 // End of main method
}

