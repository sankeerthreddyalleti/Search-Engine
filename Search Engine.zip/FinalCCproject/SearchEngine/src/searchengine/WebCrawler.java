package searchengine;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashSet;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class WebCrawler 
{
    private HashSet<String> Links;
    ArrayList<String> ArrList= new ArrayList<String>();

    public WebCrawler() 
    {
        Links = new HashSet<String>();
    }

    public void GetLinks(String url,int length) //To get the links from the desired webpage
    {       
    	if (!Links.contains(url)) 
    	{
            try 
            {
                if (Links.add(url)) 
                {
                    System.out.println(url);
                    ArrList.add(url);
                    int i = ArrList.indexOf(url);
                    String name = Integer.toString(i);
                    String str = url;
                    saveUrl(name,str); 
                }
                Document doc = Jsoup.connect(url).get();
                
                Elements LinksOnPage = doc.select("a[href]"); // Parse the HTML to extract links to other URLs

                //5. For each extracted URL... go back to Step 4.
                for (Element page : LinksOnPage) 
                {
                    GetLinks(page.attr("abs:href"),length);
                }
            } 
            catch (IOException e) 
            {
                System.err.println("For '" + url + "': " + e.getMessage());
            }
        }
    }
    
    public void saveUrl(final String Fname, final String UrlStr) throws MalformedURLException, IOException 
    {
    	{ 
            try 
            { 
                URL url = new URL(UrlStr); // Create a new URL object 
                BufferedReader readr = new BufferedReader(new InputStreamReader(url.openStream()));      
                String str = Fname +".html"; // Filename in which you want to download 
                BufferedWriter BufferWriter = new BufferedWriter(new FileWriter("C:\\Users\\asus\\Desktop\\SearchEngine\\src\\Webpages\\"+str)); 
                  
                String line; //Reading each line from the stream till the end 
                while ((line = readr.readLine()) != null) 
                { 
                	BufferWriter.write(line); 
                } 
      
                readr.close(); 
                BufferWriter.close(); 
                System.out.println("Url is sucessfully downloaded"); 
            }  
            catch (MalformedURLException mue) { 
                System.out.println("Malformed URL Exception is raised"); 
            } 
            catch (IOException ie) { 
                System.out.println("IOException is raised"); 
            } 
        } 
    }
 
    public static void main(String[] args) 
    {
        new WebCrawler().GetLinks("https://www.google.ca/",10); // Giving a URL as an input
    }

}