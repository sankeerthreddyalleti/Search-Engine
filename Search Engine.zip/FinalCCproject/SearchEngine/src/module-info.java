module SearchEngine {
	exports searchengine;

	requires org.jsoup;
}